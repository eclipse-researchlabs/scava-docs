package org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.client;

import java.util.List;

import org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.model.*;
import org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.page.TestAPIPaged;

import io.reactivex.Observable;
import retrofit2.Call; 

public interface ISearchEndpoint {

	
}