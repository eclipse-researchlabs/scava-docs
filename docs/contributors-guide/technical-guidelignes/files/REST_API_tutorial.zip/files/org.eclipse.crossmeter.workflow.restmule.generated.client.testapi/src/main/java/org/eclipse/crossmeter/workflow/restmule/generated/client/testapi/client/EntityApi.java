package org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.client;

import static org.eclipse.crossmeter.workflow.restmule.core.util.PropertiesUtil.API_BASE_URL;

import java.util.List;
import java.util.concurrent.ExecutorService;

import org.eclipse.crossmeter.workflow.restmule.core.client.AbstractClient;
import org.eclipse.crossmeter.workflow.restmule.core.client.IClientBuilder;
import org.eclipse.crossmeter.workflow.restmule.core.data.IData;
import org.eclipse.crossmeter.workflow.restmule.core.data.Data;
import org.eclipse.crossmeter.workflow.restmule.core.data.IDataSet;
import org.eclipse.crossmeter.workflow.restmule.core.session.ISession;
import org.eclipse.crossmeter.workflow.restmule.core.session.RateLimitExecutor;
import org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.cache.TestAPICacheManager;
import org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.interceptor.TestAPIInterceptor;
import org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.model.*;
import org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.page.TestAPIPaged;
import org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.page.TestAPIPagination;
import org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.session.TestAPISession;
import org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.util.TestAPIPropertiesUtil;

import okhttp3.OkHttpClient.Builder;

public class EntityApi  {

	public static EntityBuilder create(){
		return new EntityBuilder(); 
	}
	
	public static IEntityApi createDefault(){ 
		return new EntityBuilder().setSession(TestAPISession.createPublic()).build(); 
	}
	
	/** BUILDER */
	public static class EntityBuilder 
	implements IClientBuilder<IEntityApi> { 
	
		private ISession session;
		private boolean activeCaching = true;
	
		@Override
		public IEntityApi build() {
			return (IEntityApi) new EntityClient(session, activeCaching);
		}
	
		@Override
		public IClientBuilder<IEntityApi> setSession(ISession session){
			this.session = session;
			return this;
		}
		
		@Override
		public IClientBuilder<IEntityApi> setActiveCaching(boolean activeCaching) {
			this.activeCaching = activeCaching;
			return this;
		}
	
	}
	
	/** CLIENT */
	private static class EntityClient extends AbstractClient<IEntityEndpoint> 
	implements IEntityApi 
	{
		private TestAPIPagination paginationPolicy;
		
		EntityClient(ISession session, boolean activeCaching) {
			super();

			ExecutorService executor = RateLimitExecutor.create(30, TestAPISession.class, session.id());
			TestAPIInterceptor interceptors = new TestAPIInterceptor(session.id());
			String baseurl = TestAPIPropertiesUtil.get(API_BASE_URL);

			if (!baseurl.endsWith("/")) baseurl += "/"; // FIXME Validate in Model with EVL 

			Builder clientBuilder = AbstractClient.okHttp(executor);
			
			if (activeCaching) clientBuilder = clientBuilder.cache(TestAPICacheManager.getInstance().getOkHttpCache()); // FIXME Use Lucene Instead
			clientBuilder = clientBuilder.addInterceptor(interceptors.mainInterceptor(activeCaching));
						
			this.client = clientBuilder.build();

			this.callbackEndpoint = AbstractClient.retrofit(client, baseurl).create(IEntityEndpoint.class);
			this.paginationPolicy = TestAPIPagination.get();
		}

		/** WRAPED METHODS FOR PAGINATION */
	
		@Override
		public IData<NumberValue> getSquareNumberValueByNumber(Integer number){
			Data<NumberValue> data = new Data<NumberValue>();
			data.addElement(callbackEndpoint.getSquareNumberValueByNumber(number));
			return data;
		}
		
		
	}
}
