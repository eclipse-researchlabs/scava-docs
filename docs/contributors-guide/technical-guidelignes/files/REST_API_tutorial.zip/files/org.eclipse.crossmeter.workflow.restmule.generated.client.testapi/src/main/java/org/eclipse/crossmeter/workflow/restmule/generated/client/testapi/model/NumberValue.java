package org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class NumberValue {

	public NumberValue(){}

	@JsonProperty("squared") 
	private Integer squared;
	
	public Integer getSquared() {
		return this.squared;
	}
	
	@Override
	public String toString() {
		return "NumberValue [ "
			+ "squared = " + this.squared + ", "
			+ "]"; 
	}	
}	
