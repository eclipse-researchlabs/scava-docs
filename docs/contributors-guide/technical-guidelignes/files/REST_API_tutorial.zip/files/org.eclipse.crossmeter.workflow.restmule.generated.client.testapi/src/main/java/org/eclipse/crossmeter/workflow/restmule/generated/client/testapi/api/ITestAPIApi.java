package org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.api;

import org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.client.IEntityApi;
import org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.client.ISearchApi;

public interface ITestAPIApi extends IEntityApi, ISearchApi {

}
