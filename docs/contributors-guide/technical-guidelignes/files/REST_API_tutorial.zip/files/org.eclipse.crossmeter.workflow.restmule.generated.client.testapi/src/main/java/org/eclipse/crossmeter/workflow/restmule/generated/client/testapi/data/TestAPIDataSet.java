package org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.data;

import org.eclipse.crossmeter.workflow.restmule.core.data.AbstractDataSet;
import org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.page.TestAPIPagination;

public class TestAPIDataSet<T> extends AbstractDataSet<T> {

	public TestAPIDataSet(){
		super(TestAPIPagination.get());
	}
	
}
