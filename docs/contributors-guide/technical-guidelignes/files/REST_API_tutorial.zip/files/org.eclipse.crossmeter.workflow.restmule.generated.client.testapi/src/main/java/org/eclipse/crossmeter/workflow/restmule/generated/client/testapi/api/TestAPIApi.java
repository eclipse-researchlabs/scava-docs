package org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.api;

import org.apache.commons.lang3.Validate;
import org.eclipse.crossmeter.workflow.restmule.core.client.IClientBuilder;
import org.eclipse.crossmeter.workflow.restmule.core.data.IData;
import org.eclipse.crossmeter.workflow.restmule.core.data.IDataSet;
import org.eclipse.crossmeter.workflow.restmule.core.session.ISession;
import org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.client.EntityApi;
import org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.client.IEntityApi;
import org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.client.SearchApi;
import org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.client.ISearchApi;
import org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.model.*;
import org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.session.TestAPISession;

public class TestAPIApi  {

	public static TestAPIBuilder create(){
		return new TestAPIBuilder(); 
	}
	
	public static ITestAPIApi createDefault(){ 
		return new TestAPIBuilder().setSession(TestAPISession.createPublic()).build(); 
	}
	
	/** BUILDER */
	public static class TestAPIBuilder 
	implements IClientBuilder<ITestAPIApi> { 
	
		private ISession session;
		private boolean activeCaching = true;
	
		@Override
		public ITestAPIApi build() {
			return (ITestAPIApi) new TestAPIClient(session, activeCaching);
		}
	
		@Override
		public IClientBuilder<ITestAPIApi> setSession(ISession session){
			this.session = session;
			return this;
		}
		
		@Override
		public IClientBuilder<ITestAPIApi> setActiveCaching(boolean activeCaching) {
			this.activeCaching = activeCaching;
			return this;
		}
	
	}
	
	/** CLIENT */
	private static class TestAPIClient implements ITestAPIApi {
		
		private IEntityApi entityClient;
		private ISearchApi searchClient;
		
		TestAPIClient(ISession session, boolean activeCaching) {
			if (session == null) {
				session = TestAPISession.createPublic(); 
			}	
			entityClient = EntityApi.create()
				.setSession(TestAPISession.Factory.copy(session))
				.setActiveCaching(activeCaching)
				.build();
			searchClient = SearchApi.create()
				.setSession(TestAPISession.Factory.copy(session))
				.setActiveCaching(activeCaching)
				.build();
		}

		/** WRAPED METHODS */
		 
		@Override
		public IData<NumberValue> getSquareNumberValueByNumber(Integer number){ 
			Validate.notNull(number);
			return entityClient.getSquareNumberValueByNumber(number);
		}
	}
}
