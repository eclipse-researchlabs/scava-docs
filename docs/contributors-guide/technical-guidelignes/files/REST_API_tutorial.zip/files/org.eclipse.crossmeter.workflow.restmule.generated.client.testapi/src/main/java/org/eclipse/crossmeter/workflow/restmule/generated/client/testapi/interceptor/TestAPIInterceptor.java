package org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.interceptor;

import static org.eclipse.crossmeter.workflow.restmule.core.util.PropertiesUtil.ACCEPT;
import static org.eclipse.crossmeter.workflow.restmule.core.util.PropertiesUtil.RATE_LIMIT_LIMIT;
import static org.eclipse.crossmeter.workflow.restmule.core.util.PropertiesUtil.RATE_LIMIT_REMAINING;
import static org.eclipse.crossmeter.workflow.restmule.core.util.PropertiesUtil.RATE_LIMIT_RESET;
import static org.eclipse.crossmeter.workflow.restmule.core.util.PropertiesUtil.USER_AGENT;

import org.eclipse.crossmeter.workflow.restmule.core.interceptor.AbstractInterceptor;
import org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.session.TestAPISession;
import org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.util.TestAPIPropertiesUtil;

import okhttp3.Interceptor;

public class TestAPIInterceptor extends AbstractInterceptor {
	
	public TestAPIInterceptor(String session){
		this.sessionId = session;
	}

	static {
		sessionClass = TestAPISession.class;
		headerLimit = TestAPIPropertiesUtil.get(RATE_LIMIT_LIMIT);
		headerRemaining = TestAPIPropertiesUtil.get(RATE_LIMIT_REMAINING);
		headerReset = TestAPIPropertiesUtil.get(RATE_LIMIT_RESET);
		userAgent = TestAPIPropertiesUtil.get(USER_AGENT);
		accept = TestAPIPropertiesUtil.get(ACCEPT);
	}

	public Interceptor mainInterceptor(boolean activeCaching){
		return mainInterceptor(userAgent, accept,cache, sessionId, headerLimit, headerRemaining, headerReset);
	}
	
}