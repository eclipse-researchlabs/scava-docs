package org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.client;

import static org.eclipse.crossmeter.workflow.restmule.core.util.PropertiesUtil.API_BASE_URL;

import java.util.List;
import java.util.concurrent.ExecutorService;

import org.eclipse.crossmeter.workflow.restmule.core.client.AbstractClient;
import org.eclipse.crossmeter.workflow.restmule.core.client.IClientBuilder;
import org.eclipse.crossmeter.workflow.restmule.core.data.IData;
import org.eclipse.crossmeter.workflow.restmule.core.data.Data;
import org.eclipse.crossmeter.workflow.restmule.core.data.IDataSet;
import org.eclipse.crossmeter.workflow.restmule.core.session.ISession;
import org.eclipse.crossmeter.workflow.restmule.core.session.RateLimitExecutor;
import org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.cache.TestAPICacheManager;
import org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.interceptor.TestAPIInterceptor;
import org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.model.*;
import org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.page.TestAPIPaged;
import org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.page.TestAPIPagination;
import org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.session.TestAPISession;
import org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.util.TestAPIPropertiesUtil;

import okhttp3.OkHttpClient.Builder;

public class SearchApi  {

	public static SearchBuilder create(){
		return new SearchBuilder(); 
	}
	
	public static ISearchApi createDefault(){ 
		return new SearchBuilder().setSession(TestAPISession.createPublic()).build(); 
	}
	
	/** BUILDER */
	public static class SearchBuilder 
	implements IClientBuilder<ISearchApi> { 
	
		private ISession session;
		private boolean activeCaching = true;
	
		@Override
		public ISearchApi build() {
			return (ISearchApi) new SearchClient(session, activeCaching);
		}
	
		@Override
		public IClientBuilder<ISearchApi> setSession(ISession session){
			this.session = session;
			return this;
		}
		
		@Override
		public IClientBuilder<ISearchApi> setActiveCaching(boolean activeCaching) {
			this.activeCaching = activeCaching;
			return this;
		}
	
	}
	
	/** CLIENT */
	private static class SearchClient extends AbstractClient<ISearchEndpoint> 
	implements ISearchApi 
	{
		private TestAPIPagination paginationPolicy;
		
		SearchClient(ISession session, boolean activeCaching) {
			super();

			ExecutorService executor = RateLimitExecutor.create(30, TestAPISession.class, session.id());
			TestAPIInterceptor interceptors = new TestAPIInterceptor(session.id());
			String baseurl = TestAPIPropertiesUtil.get(API_BASE_URL);

			if (!baseurl.endsWith("/")) baseurl += "/"; // FIXME Validate in Model with EVL 

			Builder clientBuilder = AbstractClient.okHttp(executor);
			
			if (activeCaching) clientBuilder = clientBuilder.cache(TestAPICacheManager.getInstance().getOkHttpCache()); // FIXME Use Lucene Instead
			clientBuilder = clientBuilder.addInterceptor(interceptors.mainInterceptor(activeCaching));
						
			this.client = clientBuilder.build();

			this.callbackEndpoint = AbstractClient.retrofit(client, baseurl).create(ISearchEndpoint.class);
			this.paginationPolicy = TestAPIPagination.get();
		}

		/** WRAPED METHODS FOR PAGINATION */
	
		
	}
}
