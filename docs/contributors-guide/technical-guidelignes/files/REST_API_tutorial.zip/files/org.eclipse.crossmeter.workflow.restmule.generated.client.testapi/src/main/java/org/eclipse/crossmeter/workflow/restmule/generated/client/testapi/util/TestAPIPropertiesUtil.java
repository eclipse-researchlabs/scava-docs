package org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.util;

import java.util.Properties;

import org.eclipse.crossmeter.workflow.restmule.core.util.PropertiesUtil;

public class TestAPIPropertiesUtil {

	private static final String PROPERTIES_FILE = "testapi.properties";

	public static String get(String property){
		Properties properties = PropertiesUtil.load(TestAPIPropertiesUtil.class, PROPERTIES_FILE);
		return properties.getProperty(property);
	}

}