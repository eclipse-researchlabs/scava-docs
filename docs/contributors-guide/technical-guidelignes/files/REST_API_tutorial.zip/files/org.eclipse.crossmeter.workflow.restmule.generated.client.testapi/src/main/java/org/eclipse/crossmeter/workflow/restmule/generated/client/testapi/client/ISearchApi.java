package org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.client;

import org.eclipse.crossmeter.workflow.restmule.core.data.IData;
import org.eclipse.crossmeter.workflow.restmule.core.data.IDataSet;
import org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.model.*;

public interface ISearchApi {
	
}