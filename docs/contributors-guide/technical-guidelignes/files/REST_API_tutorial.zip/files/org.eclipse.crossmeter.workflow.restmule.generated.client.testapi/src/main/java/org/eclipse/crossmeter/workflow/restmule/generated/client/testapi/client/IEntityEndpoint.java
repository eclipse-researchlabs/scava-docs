package org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.client;

import java.util.List;

import org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.model.*;
import org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.page.TestAPIPaged;

import io.reactivex.Observable;
import retrofit2.Call; 
import retrofit2.http.Path;
import retrofit2.http.GET;

public interface IEntityEndpoint {

	
		// FIXME using endocde=true caused Lucene (cache) to break
		@GET("/square/{number}")
		Observable<NumberValue> getSquareNumberValueByNumber(			
				@Path(value="number", encoded=true) Integer number);
	
}