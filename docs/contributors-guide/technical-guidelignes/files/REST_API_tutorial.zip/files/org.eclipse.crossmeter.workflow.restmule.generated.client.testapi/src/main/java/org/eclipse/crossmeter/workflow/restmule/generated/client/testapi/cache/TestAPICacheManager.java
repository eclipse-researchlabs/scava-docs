package org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.cache;

import org.eclipse.crossmeter.workflow.restmule.core.cache.AbstractCacheManager;
import org.eclipse.crossmeter.workflow.restmule.core.cache.ICache;

public class TestAPICacheManager extends AbstractCacheManager {

	private static final String AGENT_NAME = "testapi"; 

	private static TestAPICacheManager agent;

	public static ICache getInstance() {
		if (TestAPICacheManager.agent == null){
			TestAPICacheManager.agent = new TestAPICacheManager();
		} 
		return TestAPICacheManager.agent;
	}

	private TestAPICacheManager() { 
		super(AGENT_NAME);
	}
}
