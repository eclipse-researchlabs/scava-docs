package org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.page;

import static org.eclipse.crossmeter.workflow.restmule.core.util.PropertiesUtil.PAGE_INCREMENT;
import static org.eclipse.crossmeter.workflow.restmule.core.util.PropertiesUtil.PAGE_LABEL;
import static org.eclipse.crossmeter.workflow.restmule.core.util.PropertiesUtil.PAGE_MAX_VALUE;
import static org.eclipse.crossmeter.workflow.restmule.core.util.PropertiesUtil.PAGE_START_VALUE;
import static org.eclipse.crossmeter.workflow.restmule.core.util.PropertiesUtil.PER_ITERATION_LABEL;
import static org.eclipse.crossmeter.workflow.restmule.core.util.PropertiesUtil.PER_ITERATION_VALUE;

import org.eclipse.crossmeter.workflow.restmule.core.data.IDataSet;
import org.eclipse.crossmeter.workflow.restmule.core.page.AbstractPagination;
import org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.callback.TestAPICallback;
import org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.callback.TestAPIWrappedCallback;
import org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.data.TestAPIDataSet;
import org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.util.TestAPIPropertiesUtil;

import io.reactivex.annotations.NonNull;

public class TestAPIPagination extends AbstractPagination{

	private static TestAPIPagination instance;

	public static TestAPIPagination get(){
		if (instance == null){
			instance = new TestAPIPagination();
		}
		return instance;
	}

	private TestAPIPagination() {
		super(	TestAPIPropertiesUtil.get(PAGE_LABEL),
				TestAPIPropertiesUtil.get(PER_ITERATION_LABEL), 
				Integer.valueOf(TestAPIPropertiesUtil.get(PER_ITERATION_VALUE)),
				Integer.valueOf(TestAPIPropertiesUtil.get(PAGE_MAX_VALUE)), 
				Integer.valueOf(TestAPIPropertiesUtil.get(PAGE_START_VALUE)),
				Integer.valueOf(TestAPIPropertiesUtil.get(PAGE_INCREMENT)));
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public <T, WRAP extends TestAPIPaged<T>, END> IDataSet<T> traverse(
			@NonNull String methodName, 
			@NonNull Class<?>[] types, 
			@NonNull Object[] vals, 
			@NonNull END client)
	{
		return super.<T, WRAP, END, TestAPIDataSet<T>, TestAPIWrappedCallback>
		traverse(new TestAPIWrappedCallback<T, WRAP>(), methodName, types, vals, client);
	}
	
	public <T, END> IDataSet<T> traverseList(
			@NonNull String methodName, 
			@NonNull Class<?>[] types, 
			@NonNull Object[] vals, 
			@NonNull END client)
	{
		return super.<T, END, TestAPIDataSet<T>, TestAPICallback<T>>
		traversePages(new TestAPICallback<T>(), methodName, types, vals, client);		
	}

}
