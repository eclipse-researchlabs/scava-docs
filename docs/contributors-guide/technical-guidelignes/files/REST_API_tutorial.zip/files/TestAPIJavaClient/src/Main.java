import java.util.Scanner;

import org.eclipse.crossmeter.workflow.restmule.core.data.IData;
import org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.api.ITestAPIApi;
import org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.api.TestAPIApi;
import org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.model.NumberValue;

public class Main {

	public static void main(String[] main) {
		
		ITestAPIApi api = TestAPIApi.createDefault();
		int numba;
		
		System.out.println("Gimme a numba: ");
		Scanner scanner = new Scanner(System.in);
		numba = scanner.nextInt();
		scanner.close();

		IData<NumberValue> squared = api.getSquareNumberValueByNumber(numba);

		// squared.observe().subscribe(numberValue -> {
		// System.out.println("Squared: " + numberValue.getSquared());
		// });

		NumberValue numberValue = squared.observe().blockingSingle();
		System.out.println("Squared: " + numberValue.getSquared());
		
	}
}
