package testapi.server;

import javax.annotation.PreDestroy;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Component;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

@Component
public class RateLimitingInterceptor extends HandlerInterceptorAdapter {
 
    private int hourlyLimit = 36000;
      
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws Exception {
        response.addHeader("X-RateLimit-Limit", String.valueOf(hourlyLimit));
        return true;
    }
     
    @PreDestroy
    public void destroy() {
        // loop and finalize all limiters
    }
}