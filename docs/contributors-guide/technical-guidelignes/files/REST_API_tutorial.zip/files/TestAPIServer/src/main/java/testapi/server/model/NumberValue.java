package testapi.server.model;

public class NumberValue {
	private int squared;

	public int getSquared() {
		return squared;
	}

	public void setSquared(int squared) {
		this.squared = squared;
	}

}
