package testapiplugin.view;

import org.eclipse.crossmeter.workflow.restmule.core.data.IData;
import org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.api.ITestAPIApi;
import org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.api.TestAPIApi;
import org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.client.EntityApi;
import org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.client.IEntityApi;
import org.eclipse.crossmeter.workflow.restmule.generated.client.testapi.model.NumberValue;
import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Spinner;

import io.reactivex.Observable;

import org.eclipse.swt.layout.GridData;

public class Square extends Dialog {

	private Spinner numberToBeSquared;
	private Label result;

	/**
	 * Create the dialog.
	 * 
	 * @param parentShell
	 */
	public Square(Shell parentShell) {
		super(parentShell);
	}

	/**
	 * Create contents of the dialog.
	 * 
	 * @param parent
	 */
	@Override
	protected Control createDialogArea(Composite parent) {
		Composite container = (Composite) super.createDialogArea(parent);
		container.setLayout(new GridLayout(2, false));

		Label lblNumberToBe = new Label(container, SWT.NONE);
		GridData gd_lblNumberToBe = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_lblNumberToBe.widthHint = 192;
		lblNumberToBe.setLayoutData(gd_lblNumberToBe);
		lblNumberToBe.setText("Number to be squared:");

		numberToBeSquared = new Spinner(container, SWT.BORDER);
		numberToBeSquared.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, true, false, 1, 1));

		Label lblSquaredValue = new Label(container, SWT.NONE);
		lblSquaredValue.setText("Squared value:");

		result = new Label(container, SWT.NONE);
		result.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		result.setText("-");
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);
		new Label(container, SWT.NONE);

		return container;
	}

	/**
	 * Create contents of the button bar.
	 * 
	 * @param parent
	 */
	@Override
	protected void createButtonsForButtonBar(Composite parent) {
		createButton(parent, IDialogConstants.OK_ID, "Send", true);
		createButton(parent, IDialogConstants.CANCEL_ID, "Close", false);
	}

	/**
	 * Return the initial size of the dialog.
	 */
	@Override
	protected Point getInitialSize() {
		return new Point(303, 139);
	}

	@Override
	protected void okPressed() {
		String numberAsString = numberToBeSquared.getText();
		int number = Integer.parseInt(numberAsString);

		ITestAPIApi api = TestAPIApi.createDefault();
		IData<NumberValue> receivedData = api.getSquareNumberValueByNumber(number);
		Observable<NumberValue> observable = receivedData.observe();
		NumberValue numberValue = observable.blockingFirst();
		System.out.println("NumberValue: "+numberValue);
		result.setText(String.valueOf(numberValue.getSquared()));
	}

}
